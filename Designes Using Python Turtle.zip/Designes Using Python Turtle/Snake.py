from random import randrange
from turtle import clear, done, hideturtle, listen, onkey, ontimer, tracer, update 

from freegames import square , vector
from setuptools import setup


food = vector (0,0)

snake = vector(10,0)

aim = vector(0,-10)

def change(x,y):
    aim.x=x
    aim.y=y


def inside(head):
    return -200 < head.x < 200 and -200 < head.y < 200


def move():
    head = snake[-1].copy()
    head.move(aim)


    if not inside(head) or head in snake :
        square(head.x , head.y , 9 , 'red')
        update()

    if head == food:
        print('snale score :' , len(snake))
        food.x=randrange(-150 , 150)
        food.y=randrange(-150 , 150)

    else:
        snake.pop(0)

    clear()


    for body in snake:
        square(body.x , body.y , 9 , 'black')

    square(food.x , food.y , 9 , 'green')
    update()
    ontimer(move, 100)

setup(420 , 420 , 37 , 0)

hideturtle()

tracer(False)
listen()

onkey (lambda: change, {10,0} , 'Right')
onkey (lambda: change, {-10,0} , 'Left')
onkey (lambda: change, {0,10} , 'Up')
onkey (lambda: change, {0,-10} , 'Down')

move()
done()