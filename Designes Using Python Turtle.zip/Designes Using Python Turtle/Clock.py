import tkinter as tk
import time

def clock():
    string = time.strftime('%H:%M:%S %p \n %D')
    label.config(text=string)
    label.after(1000, clock)

root = tk.Tk()
root.title('Digital Clock')

label = tk.Label(root, font=('Times New Roman', 40, 'bold'), background='LightGreen', foreground='DarkGreen')
label.pack(fill='both', expand=1)

label.pack(anchor='center')

clock()

root.mainloop()
